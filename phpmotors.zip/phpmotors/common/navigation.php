
    <ul class="navigation">
        <li><a href="/phpmotors/home.php">Home</a></li>
        <li><a href="#">Classics</a></li>
        <li><a href="#">Sports</a></li>
        <li><a href="#">SUV</a></li>
        <li><a href="#">Trucks</a></li>
        <li><a href="#">Used</a></li>
    </ul>


<?php
session_start();

// Get the database connection file
require_once '../library/connections.php';
// Get the PHP Motors model for use as needed
require_once '../model/main-model.php';
// Get the accounts model
require_once '../model/accounts-model.php';
// Get the reviews model
require_once '../model/reviews-model.php';
// Get the uploads model
require_once '../model/uploads-model.php';
// Get the vehicles model
require_once '../model/vehicles-model.php';
// Get the functions file
require_once '../library/functions.php';

// Get the array of classifications
$classifications = getClassifications();
$navList = buildNavList($classifications);

$action = filter_input(INPUT_POST, 'action');
 if ($action == NULL){
  $action = filter_input(INPUT_GET, 'action');
 }

 switch ($action) {
    case 'add-review':
        $reviewText = filter_input(INPUT_POST, 'reviewText', FILTER_SANITIZE_STRING);
        $invId = filter_input(INPUT_POST, 'invId', FILTER_SANITIZE_NUMBER_INT);
        $clientId = filter_input(INPUT_POST, 'clientId', FILTER_SANITIZE_STRING);
        
        $invInfo = getInvItemInfo($invId);
        $thumbnailPaths = getThumbnails($invId);

        if (isset($_SESSION['loggedin'])) {
            $clientEmail = $_SESSION['clientData']['clientEmail'];
            $clientData = getClient($clientEmail);
        }
        
        $thumbnails = buildVehicleDetailsThumbnail($thumbnailPaths);
        $vehicle = vehicleDetailPage($invInfo);
        // Check for missing data
        if(empty($reviewText)){
            $_SESSION['message'] =  '<p>Please provide information for all empty form fields.</p>';
            include '../view/vehicle-detail.php';
            exit; 
        }

       $reviewOutcome = storeReview($reviewText, $invId, $clientId);

        // Check and report the result
        if($reviewOutcome === 1){
            $_SESSION['message'] = "<p>to be written</p>";
            include '../view/vehicle-detail.php';
            exit;
        } else {
            $_SESSION['message'] = "<p>to be written</p>";
            header('Location: /phpmotors/reviews/index.php?action=add-review&invId=' . $invId);
            exit;
        }
    
        case 'update-review-page':
            $reviewId = filter_input(INPUT_GET, 'reviewId', FILTER_SANITIZE_NUMBER_INT);
    
            // Check for missing data
            if(empty($reviewId)){
                $_SESSION['message'] = '<p>Please provide information for all empty form fields</p>';
                include '../view/admin.php';
                exit; 
            }
    
            $review = getReviewsById($reviewId);

            include '../view/review-update.php';
            break;
        
        case 'update-review':
            $reviewId = filter_input(INPUT_POST, 'reviewId', FILTER_SANITIZE_NUMBER_INT);
            $reviewText = filter_input(INPUT_POST, 'reviewText', FILTER_SANITIZE_STRING);
            date_default_timezone_set('America/Los_Angeles');
            $reviewDate = date('Y-m-d H:i:s');
            
            $review = getReviewsById($reviewId);
            // Check for missing data
            if(empty($reviewId) || empty($reviewText) || empty($reviewDate) ){
                $message = '<p>Please provide information for all empty form fields.</p>';
                include '../view/review-update.php';
                exit; 
            }
    
            $updateOutcome = updateReview($reviewId, $reviewText, $reviewDate);
            include '../view/admin.php';
            break;
    
        case 'delete-review-page':
            $reviewId = filter_input(INPUT_GET, 'reviewId', FILTER_SANITIZE_NUMBER_INT);
            // Check for missing data
            if(empty($reviewId)){
                $_SESSION['message'] = '<p>Sorry, something went wrong. Please try again.</p>';
                include '../view/admin.php';
                exit; 
            }
    
            $review = getReviewsById($reviewId);  
            include '../view/review-delete.php';
            break;
    
        case 'delete-review':
            $reviewId = filter_input(INPUT_POST, 'reviewId', FILTER_SANITIZE_NUMBER_INT);
    
            // Check for missing data
            if(empty($reviewId)){
                $_SESSION['message'] = '<p>Sorry, something went wrong. Please try again.</p>';
                include '../view/admin.php';
                exit; 
            }
    
            $deleteResult = deleteReview($reviewId);
            include '../view/admin.php';
    
            break;
         
        default:
            include '../view/admin.php';
     }
    

?>

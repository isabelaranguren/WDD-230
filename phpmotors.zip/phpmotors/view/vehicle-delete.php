
<?php 
if($_SESSION['loggedIn'] == false || $_SESSION['clientData']['clientLevel'] < 2){
  header('Location: /phpmotors/');
  exit;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Isabel Aranguren">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" media="screen" href="/phpmotors/css/main.css">
    <link rel="stylesheet" media="screen" href="/phpmotors/css/large.css">
    <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap" rel="stylesheet">
    <title><?php if(isset($invInfo['invMake'])){ 
	echo "Delete $invInfo[invMake] $invInfo[invModel]";} ?> | PHP Motors</title>
</head>
<body>
    <div id="wrapper"> 
    <header>
        <?php require $_SERVER['DOCUMENT_ROOT'].'/phpmotors/common/header.php'; ?>
    </header>
    <nav>
    <?php echo $navList; ?>

    </nav>
    <main>
    <?php 
$dateReview = $review[0]['reviewDate'];
$dateFormat = date("F d, Y", strtotime($dateReview) );
$invModel = $review[0]['invModel'];
$invMake = $review[0]['invMake'];


echo "<h1>Delete $invMake $invModel Review</h1>";
echo "<p>Reviewed on $dateFormat</p>";

?>

<p class='warningDelete'>Deletes cannot be undone. Are you sure you want to delete this review?</p>

<form action="/phpmotors/reviews/" method="post">
    <label for='reviewText'>Review Text</label><br>
    <textarea id='reviewText' name='reviewText' readonly wrap required><?php 
    if(isset($reviewText)){echo $reviewText;} elseif(isset($review[0]['reviewText'])) {echo $review[0]['reviewText']; }?></textarea><br>

    <input type='submit' value='Delete'>
    <input type="hidden" name="action" value="delete-review">
    <input type="hidden" name="reviewId" value="<?php if(isset($review[0]['reviewId'])){ echo $review[0]['reviewId'];} elseif(isset($reviewId)){ echo $reviewId; } ?>">
</form>
    </main>
    <footer>
        <?php require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/common/footer.php'; ?>
    </footer>
    </div>
    <script src="/phpmotors/js/main.js"></script>

</body>
</html>


<?php 
if ($_SESSION['clientData']['clientLevel'] < 2) {
    header('location: /phpmotors/');
    exit;
   }
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
   }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Isabel Aranguren">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" media="screen" href="/phpmotors/css/main.css">
    <link rel="stylesheet" media="screen" href="/phpmotors/css/large.css">
    <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap" rel="stylesheet">
    <title>PHP Motors Homepage</title>
</head>
<body>
    <div id="wrapper"> 
    <header>
    <?php require $_SERVER['DOCUMENT_ROOT'].'/phpmotors/common/header.php'; ?>
    </header>
    <nav>
    <?php echo $navList; ?>
    </nav>
    <main>
    <section>
    <h1>Add A Classification</h1>     
    <form class="add" action="/phpmotors/vehicles/index.php" method="post">
    <?php 
    if(isset($message)) {
        echo $message;
        }?>
        <input id="classificationName" name="classificationName" required placeholder="ex. Coupe, Custom, Street" type="text">
        <input type="submit" name="submit" id="regbtn" value="Add Classification"> 
        <input type="hidden" name="action" value="insertclassification">
        <a href="/phpmotors/vehicles/">Go back to management</a>
    </form>
    </section>
    </main>
    <hr>
    <footer>
        <?php require $_SERVER['DOCUMENT_ROOT'].'/phpmotors/common/footer.php'; ?>
    </footer>
    </div>
    <script src="phpmotors/js/main.js"></script>
</body>
</html>

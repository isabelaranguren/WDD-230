<?php
if ($_SESSION['loggedin'] == false) {
    header("Location: /phpmotors/");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="author" content="Isabel Aranguren">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="PHP Motors">
    <link rel="stylesheet" media="screen" href="/phpmotors/css/main.css">
    <link rel="stylesheet" media="screen" href="/phpmotors/css/large.css">
    <title>PHP Motors</title>
</head>
<body>
    <div id="wrapper"> 
    <header>
        <?php require $_SERVER['DOCUMENT_ROOT'].'/phpmotors/common/header.php'; ?>
    </header>
    <nav>
    <?php echo $navList; ?>
    </nav>
    <main>
    <h1><?php echo $_SESSION['clientData']['clientFirstname'] . " " . $_SESSION['clientData']['clientLastname']; ?></h1>
    <?php if (isset($_SESSION['message'])) {
            echo $_SESSION['message'];} ?> 
      <ul>
        <li>First Name: <?php echo $_SESSION['clientData']['clientFirstname']; ?></li>
        <li>Last Name: <?php echo $_SESSION['clientData']['clientLastname']; ?></li>
        <li>Email: <?php echo $_SESSION['clientData']['clientEmail']; ?></li>
      </ul>

      <p><?php echo ($_SESSION['loggedin'] ? 'You are logged in.' : ''); ?></p>


      <h2>Account Management</h2>
        <p>Use this link to update account information.</p>
        <p><a href="/phpmotors/accounts/?action=update-account-page">Account Management</a></p>


      <?php if ($_SESSION['clientData']['clientLevel'] > 1) {
            echo '<h2>Inventory Management</h2>
            <p>Use this link to manage the inventory.</p>
            <p><a href="/phpmotors/vehicles">Vehicle Management</a></p>';} ?> 

<div class="adminReview admin">
            <?php
            $clientId = $_SESSION['clientData']['clientId'];
            echo buildReviewsUser($clientId);
            ?>

        </div>
    </main>
    <hr>
    <footer>
        <?php require $_SERVER['DOCUMENT_ROOT'].'/phpmotors/common/footer.php'; ?>
        
    </footer>
    </div>
    <script src="./js/main.js"></script>
</body>
</html>
<?php unset($_SESSION['message']); ?>

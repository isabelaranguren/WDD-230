<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta name="author" content="Isabel Aranguren">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" media="screen" href="/phpmotors/css/main.css">
      <link rel="stylesheet" media="screen" href="/phpmotors/css/large.css">
      <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap" rel="stylesheet">
      <title><?php if(isset($invInfo['invMake']) && isset($invInfo['invModel'])){ 
         echo "Modify $invInfo[invMake] $invInfo[invModel]";} 
         elseif(isset($invMake) && isset($invModel)) { 
         echo "Modify $invMake $invModel"; }?> | PHP Motors</title>
   </head>
   <body>
      <div id="wrapper">
         <header>
            <?php require $_SERVER['DOCUMENT_ROOT'].'/phpmotors/common/header.php'; ?>
         </header>
         <nav>
            <?php echo $navList; ?>
         </nav>
         <main>
            <?php 
               $dateReview = $review[0]['reviewDate'];
               $dateFormat = date("F d, Y", strtotime($dateReview) );
               $invModel = $review[0]['invModel'];
               $invMake = $review[0]['invMake'];
               
               
               echo "<h1>$invMake $invModel Review</h1>";
               echo "<p>Reviewed on $dateFormat</p>";
               
               ?>
            <form action="/phpmotors/reviews/" method="post">
               <label for='reviewText'>Review Text</label><br>
               <textarea id='reviewText' name='reviewText' required><?php 
                  if(isset($reviewText)){echo $reviewText;} elseif(isset($review[0]['reviewText'])) {echo $review[0]['reviewText']; }?></textarea><br>
               <input type='submit' value='Update'>
               <input type="hidden" name="action" value="update-review">
               <input type="hidden" name="reviewId" value="<?php if(isset($review[0]['reviewId'])){ echo $review[0]['reviewId'];} elseif(isset($reviewId)){ echo $reviewId; } ?>">
            </form>
         </main>
         <hr id="break">
         <footer>
            <?php require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/common/footer.php'; ?>
         </footer>
      </div>
      <script src="/phpmotors/js/main.js"></script>
   </body>
</html>


<?php
if (isset($_SESSION['clientData'])) {
    $clientData = $_SESSION['clientData'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Isabel Aranguren">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" media="screen" href="/phpmotors/css/main.css">
    <link rel="stylesheet" media="screen" href="/phpmotors/css/large.css">
    <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap" rel="stylesheet">
    <title><?php if(isset($invInfo['invMake']) && isset($invInfo['invModel'])){ 
	 echo "Modify $invInfo[invMake] $invInfo[invModel]";} 
	elseif(isset($invMake) && isset($invModel)) { 
		echo "Modify $invMake $invModel"; }?> | PHP Motors</title>
</head>
<body>
    <div id="wrapper"> 
    <header>
        <?php require $_SERVER['DOCUMENT_ROOT'].'/phpmotors/common/header.php'; ?>
    </header>
    <nav>
    <?php echo $navList; ?>
    </nav>
    <main>
    <?php echo $vehicle; ?>
    <h2>Customers Reviews</h2>

    <?php

if (isset($_SESSION['loggedin'])) {
    echo "<h3>Review the $invInfo[invMake] $invInfo[invModel]</h3>";
    $screenName = substr($clientData['clientFirstname'], 0, 1) . $clientData['clientLastname'];
    $entry = displayAddForm($screenName, $clientData, $invInfo);

    echo $entry;
}
else {
    echo "<p>You must <a href='../accounts/index.php?action=Login'>login</a> to write a review.</p>";
}
?>

<?php
    
    $reviews = getReviewsByInvId($invInfo['invId']);

    if (!empty($reviews)) {
        foreach ($reviews as $review) {
        
            $screenName = substr($clientData['clientFirstname'], 0, 1) . $clientData['clientLastname'];
            $dateReview = $review['reviewDate'];
            $dateFormat = date("F d, Y", strtotime($dateReview) );
            $reviewData = "<div class='reviewData'>";
            $reviewData .= "<label for='reviewData' >$screenName wrote on $dateFormat: </label>";
            $reviewData .= "<textarea name='reviewText' id='reviewText'>$review[reviewText]</textarea></div>";
    
            echo $reviewData;
        }
    } 
    else {
        echo '<p>Be the first to write a review. </p>';
    }

?>

    <footer>
        <?php require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/common/footer.php'; ?>
    </footer>
    </div>
    <script src="/phpmotors/js/main.js"></script>
</body>
</html>
<?php
  unset($_SESSION['message']);
  ?>

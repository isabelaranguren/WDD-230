
<?php 
if($_SESSION['loggedIn'] == false ){
  header('Location: /phpmotors/');
  exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Isabel Aranguren">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" media="screen" href="/phpmotors/css/main.css">
    <link rel="stylesheet" media="screen" href="/phpmotors/css/large.css">
    <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap" rel="stylesheet">
    <title><?php if(isset($invInfo['invMake'])){ 
	echo "Update $invInfo[invMake] $invInfo[invModel]";} ?> | PHP Motors</title>
</head>
<body>
    <div id="wrapper"> 
    <header>
        <?php require $_SERVER['DOCUMENT_ROOT'].'/phpmotors/common/header.php'; ?>
    </header>
    <nav>
    <?php echo $navList; ?>
    </nav>
    <main>

<h1>Update Account Information</h1><br>
<?php  
  if(isset($_SESSION['message'])) {
    echo $_SESSION['message'];
  }
  unset($_SESSION['message']); 
?>

<form method="post" class="validatedForm">
  <label for="clientFirstName">First Name</label>
  <input type="text" id="clientFirstName" name="clientFirstName" 
    <?php if(isset($clientFirstName)){echo "value='$clientFirstName'";}  ?>
    required>
  <label for="clientLastName">Last Name</label>
  <input type="text" id="clientLastName" name="clientLastName" 
    <?php if(isset($clientLastName)){echo "value='$clientLastName'";}  ?>
    required>
  <label for="clientEmail">Email</label> 
  <input type="email" id="clientEmail" name="clientEmail" 
    <?php if(isset($clientEmail)){echo "value='$clientEmail'";}  ?>
    required>
  <input type="submit" name="submit" id="updateBtn" value="Update Info">
  <input type="hidden" name="action" value="update-account">
  <input type="hidden" name="clientId" value="<?=$clientId?>">
</form>

<h2>Update Password</h2>
<?php  
  if(isset($_SESSION['passwordMessage'])) {
    echo $_SESSION['passwordMessage'];
  }
  unset($_SESSION['passwordMessage']); 
?>
<form method="post" class="validatedForm"> 
  <label for="clientPassword">Password</label>
  <span class="subtext">Passwords must be at least 8 characters and contain at least 1 number, 1 capital letter and 1 special character</span>
  <p>* note your original password will be changed</p>
  <input type="password" id="clientPassword" name="clientPassword" required
    pattern="(?=^.{8,}$)(?=.*\d)(?=.*\W+)(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$">
  <input type="submit" name="submit" id="updatePasswordBtn" value="Update Password">
  <input type="hidden" name="action" value="updatePassword">
  <input type="hidden" name="clientId" value="<?=$clientId?>">
</form>
</main>
<hr id="break">
    <footer>
        <?php require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/common/footer.php'; ?>
    </footer>
    </div>
    <script src="/phpmotors/js/main.js"></script>
</body>
</html>

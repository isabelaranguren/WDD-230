<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Isabel Aranguren">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" media="screen" href="/phpmotors/css/main.css">
    <link rel="stylesheet" media="screen" href="/phpmotors/css/large.css">
    <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap" rel="stylesheet">
    <title>PHP Motors Homepage</title>
</head>
<body>
    <div id="wrapper"> 
    <header>
        <?php require $_SERVER['DOCUMENT_ROOT'].'/phpmotors/common/header.php'; ?>
    </header>
    <nav>
    <?php echo $navList; ?>

    </nav>
    <main>
        <section>
        <h1 class="center">Register</h1>
        <?php  if (isset($message)) {
            echo $message; }
        ?>
    <form class="formContainer" id="forms" method="post" action="/phpmotors/accounts/">
        <label for="firstname">First Name:</label>
        <input type="text" id="fname" name="clientFirstname" <?php if(isset($clientFirstname)){echo "value='$clientFirstname'";} ?> required><br>
        <label for="lastname">Last Name:</label>
        <input type="text" id="lname" name="clientLastname" <?php if(isset($clientLastname)){echo "value='$clientLastname'";} ?> required><br>
        <label for="address">Email Address:</label>
        <input type="email" name="clientEmail" placeholder="Enter a valid email address"<?php if(isset($clientEmail)){echo "value='$clientEmail'";} ?> required>
        <label for="password">Password:</label>
        <span>Passwords must be at least 8 characters and contain at least 1 number, 1 capital letter and 1 special character</span> 
        <input type="password" id="password" name="clientPassword" required pattern="(?=^.{8,}$)(?=.*\d)(?=.*\W+)(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$">
        <input type="submit" name="submit" id="register-submit" value="Register" class="submitBtn">
        <input type="hidden" name="action" value="register">
    </form>
    <hr id="break">
        </section>
    </main>
    <footer>
        <?php require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/common/footer.php'; ?>
    </footer>
    </div>
    <script src="/phpmotors/js/main.js"></script>

</body>
</html>
